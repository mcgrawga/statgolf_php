<?php 

	include("phpgraphlib.php"); 
	$graph=new PHPGraphLib(400,200);
	$data=array(	"Jan"=>2.0,
			"Feb"=>2.0,
			"Mar"=>2.2,
			"Apr"=>2.2,
			"May"=>2.3,
			"Jun"=>2.4,
			"Jul"=>2.5,
			"Aug"=>2.6,
			"Sep"=>2.7,
			"Oct"=>2.8,
			"Nov"=>2.9,
			"Dec"=>3.0);
	$graph->addData($data);
	$graph->setTitle("Putt Average");
	$graph->setBars(false);
	$graph->setLine(true);
	$graph->setDataPoints(true);
	$graph->setDataPointColor("maroon");
	$graph->setDataValues(true);
	$graph->setDataValueColor("maroon");
	//$graph->setGoalLine(2);
	$graph->setGoalLineColor("red");
	$graph->createGraph();
	


?>