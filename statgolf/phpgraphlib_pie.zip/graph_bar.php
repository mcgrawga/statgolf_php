<?php 

	include("phpgraphlib.php"); 
	$graph=new PHPGraphLib(475,300);
	//$data=array(2124,535,3373,2223,0432,3332,5544,4523,2778,8878,8787,3243,4832,2302);
		$data_1987=array(	"Jan"=>85,
				"Feb"=>82.6,
				"Mar"=>90.4,
				"Apr"=>87,
				"May"=>80,
				"Jun"=>78,
				"Jul"=>91.5,
				"Aug"=>88.3,
				"Sep"=>87,
				"Oct"=>84,
				"Nov"=>83,
				"Dec"=>86);

	$graph->addData($data_1987);
	$graph->setTitle("Average Score");
	$graph->setGradient("red", "maroon");
	$graph->createGraph();

?>